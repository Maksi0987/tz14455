﻿/// <reference types="nativewind/types" />
